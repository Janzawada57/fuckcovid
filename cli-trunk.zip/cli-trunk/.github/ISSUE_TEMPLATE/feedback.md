---
name: "\U0001F4E3 Feedback"
about: Give us general feedback about the GitHub CLI
title: ''
labels: feedback
assignees: ''

---

# CLI Feedback

You can use this template to give us structured feedback or just wipe it and leave us a note. Thank you!

## What have you loved?

_eg "the nice colors"_

## What was confusing or gave you pause?

_eg "it did something unexpected"_

## Are there features you'd like to see added?

_eg "gh cli needs mini-games"_

## Anything else?

_eg "have a nice day"_
